import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact("1234567890", "John", "Doe", "5555555555", "123 Main St");
        contactService.addContact(contact);
        Assertions.assertTrue(contactService.getContacts().containsKey("1234567890"));
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("1234567890", "John", "Doe", "5555555555", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        Assertions.assertFalse(contactService.getContacts().containsKey("1234567890"));
    }

    @Test
    void testUpdateContact() {
        Contact contact = new Contact("1234567890", "John", "Doe", "5555555555", "123 Main St");
        contactService.addContact(contact);

        // Update firstName
        contactService.updateContact("1234567890", "firstName", "Jane");
        Assertions.assertEquals("Jane", contactService.getContacts().get("1234567890").getFirstName());

        // Update lastName
        contactService.updateContact("1234567890", "lastName", "Smith");
        Assertions.assertEquals("Smith", contactService.getContacts().get("1234567890").getLastName());

        // Update phone
        contactService.updateContact("1234567890", "phone", "6666666666");
        Assertions.assertEquals("6666666666", contactService.getContacts().get("1234567890").getPhone());

        // Update address
        contactService.updateContact("1234567890", "address", "456 Elm St");
        Assertions.assertEquals("456 Elm St", contactService.getContacts().get("1234567890").getAddress());
    }
}