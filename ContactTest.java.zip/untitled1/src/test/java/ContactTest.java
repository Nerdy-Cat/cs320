import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ContactTest {

    // Test for fields being too long
    @Test
    @DisplayName("Contact fields cannot have more than specified length")
    void testContactFieldsMaxLength() {
        // Test for first name too long
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstNameTooLong", "LastName", "5555555555", "Address");
        });

        // Test for last name too long
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", "LastNameTooLong", "5555555555", "Address");
        });

        // Test for address too long
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", "LastName", "5555555555", "AddressTooLong12345678901234567890");
        });
    }

    // Test for null values in fields
    @Test
    @DisplayName("Contact fields cannot be null")
    void testContactFieldsNotNull() {
        // Test for null first name
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", null, "LastName", "5555555555", "Address");
        });

        // Test for null last name
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", null, "5555555555", "Address");
        });

        // Test for null phone number
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", "LastName", null, "Address");
        });

        // Test for null address
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", "LastName", "5555555555", null);
        });
    }

    // Test for invalid phone number length
    @Test
    @DisplayName("Contact phone number must have 10 digits")
    void testContactPhoneLength() {
        // Test for phone number with less than 10 digits
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", "LastName", "123456789", "Address");
        });

        // Test for phone number with more than 10 digits
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            new Contact("0123456789", "FirstName", "LastName", "12345678901", "Address");
        });
    }

    // Test for valid contact creation
    @Test
    @DisplayName("Valid contact creation")
    void testValidContactCreation() {
        Contact contact = new Contact("0123456789", "John", "Doe", "5555555555", "123 Main St");
        Assertions.assertEquals("0123456789", contact.getContactID());
        Assertions.assertEquals("John", contact.getFirstName());
        Assertions.assertEquals("Doe", contact.getLastName());
        Assertions.assertEquals("5555555555", contact.getPhone());
        Assertions.assertEquals("123 Main St", contact.getAddress());
    }

    // Test for updating contact fields
    @Test
    @DisplayName("Update contact fields")
    void testUpdateContactFields() {
        Contact contact = new Contact("0123456789", "John", "Doe", "5555555555", "123 Main St");

        // Update first name
        contact.setFirstName("Jane");
        Assertions.assertEquals("Jane", contact.getFirstName());

        // Update last name
        contact.setLastName("Smith");
        Assertions.assertEquals("Smith", contact.getLastName());

        // Update phone number
        contact.setPhone("6666666666");
        Assertions.assertEquals("6666666666", contact.getPhone());

        // Update address
        contact.setAddress("456 Elm St");
        Assertions.assertEquals("456 Elm St", contact.getAddress());
    }
    @Test
    @DisplayName("Default constructor initializes fields with default values")
    void testDefaultConstructor() {
        Contact contact = new Contact();
        Assertions.assertEquals("", contact.getContactID());
        Assertions.assertEquals("", contact.getFirstName());
        Assertions.assertEquals("", contact.getLastName());
        Assertions.assertEquals("", contact.getPhone());
        Assertions.assertEquals("", contact.getAddress());
    }
}